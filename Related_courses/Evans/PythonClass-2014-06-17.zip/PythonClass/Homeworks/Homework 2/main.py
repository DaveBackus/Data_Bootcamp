# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 11:32:39 2014

@author: dgevans
"""
from numpy import *
import lake_model as lm
import matplotlib.pyplot as plt

#Initialize  Parameters



#Part B




#Part C




#Part D




#Part G




#Part G with no death




#Tax Computations