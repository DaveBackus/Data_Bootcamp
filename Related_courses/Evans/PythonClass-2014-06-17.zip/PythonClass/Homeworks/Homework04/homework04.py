# -*- coding: utf-8 -*-
import numpy as np
from scipy.optimize import root
from scipy.optimize import brentq
from scipy.stats import norm

def findUnitEigenvector(A):
    '''
    For a matrix A finds the unit eigenvector
    '''
    eigs,eig_vecs = np.linalg.eig(A)
    
    i = int(np.where(np.abs(eigs-1)<1e-14)[0])
    
    return np.real(eig_vecs[:,i]/eig_vecs[:,i].sum())
    
    

class WorkerProblem:
    '''
    Solves the worker problem for a set of parameters and government policies
    '''
    def __init__(self,beta,p,w,alpha,sigma):
        '''
        Initializes worker problem class with
        
        Parameters
        ===========
        
        beta : discount factor worker
        
        p : (ndarray) p[j] is the probability of receiving wage w[j]
        
        w : (ndarray) array of possibe wages the worker can receive
        
        alpha : (float) firing probability
        
        sigma: (float) Risk aversion of the worker
        '''
        pass #pass is do nothing.  You will want to replace this
        
    def U(self,x):
        '''
        Returns the utility of the agent
        '''
        sigma = self.sigma
        if sigma == 1:
            return np.log(x)
        else:
            return (x**(1-sigma)-1.)/(1.-sigma)
        
    def iterateValueFunction(self,c,tau,v):
        '''
        Iterates workers bellman equation
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        v : (ndarray) current value function
        
        Returns
        ========
        
        vnew : (ndarray) new value function
        
        choice :(ndarrary) optimal decision rule of the worker
        '''
        pass #pass is do nothing.  You will want to replace this
        
    def solveBellmanEquation(self,c,tau,eps = 1e-10):
        '''
        Solves workers bellman equation given government policies
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        V : (ndarray)  value function
        
        Choice :(ndarrary) optimal decision rule of the worker
        '''
        pass #pass is do nothing.  You will want to replace this
        
    def constructTransitionMatrix(self,c,tau):
        '''
        Computes the transition matrix of the worker of the infinite horizon
        problem given government policy
         Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        P : (ndarray)  Transition matrix taking s=0 as unemployed
        '''
        pass #pass is do nothing.  You will want to replace this
        
    def constructSteadyState(self,c,tau):
        '''
        Finds the steady state distribution of worker productivities
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        pi : (ndarray)  steady state distribution
        '''
        pass #pass is do nothing.  You will want to replace this
        
    def computeSS_Deficit(self,c,tau):
        '''
        Computes the governments budget deficit in the steady state
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        deficit :   (float) government unemployment payments minus tax income
        '''
        pass #pass is do nothing.  You will want to replace this
        
    def computeSS_Welfare(self,c,tau):
        '''
        Computes the governemnts steady state welfare
        '''
        pass #pass is do nothing.  You will want to replace this
        
        
def bracket_and_solve(f):
    '''
    Helper function.  Given a decreasing function f on [0,1] will find the 
    root of that function.
    
    Parameters
    ===========
    
    f   :   A function f:[0,1]->R
    
    Returns
    ========
    x0 such that f(x0) = 0
    '''
    x0 = 0.2
    if f(x0) < 0.:
        x1 = x0/1.1
        while f(x1) < 0:
            x0 = x1
            x1 = x0/1.1
        return brentq(f,x1,x0)
    elif f(x0) > 0:
        x1  =  0.9*x0+0.1
        while f(x1) > 0.:
            x0 = x1
            x1 = 0.9*x0+0.1
        return brentq(f,x0,x1)
    
        

def compute_tau(WP,c):
    '''
    Computes the tax rate that balances the governments budget contraint
    Parameters
    ==========
    
    WP  :   An instance of WorkerProblem class
    
    c   :   Unemployement benefits
    
    Returns
    ========
    
    tau :   Budget constraint balancing tax rate
    '''
    pass #pass is do nothing.  You will want to replace this
