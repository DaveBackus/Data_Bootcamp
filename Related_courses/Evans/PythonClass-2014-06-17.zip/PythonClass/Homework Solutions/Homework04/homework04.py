# -*- coding: utf-8 -*-
import numpy as np
from scipy.optimize import root
from scipy.optimize import brentq
from scipy.stats import norm

def findUnitEigenvector(A):
    '''
    For a matrix A finds the unit eigenvector
    '''
    eigs,eig_vecs = np.linalg.eig(A)
    
    i = int(np.where(np.abs(eigs-1)<1e-14)[0])
    
    return np.real(eig_vecs[:,i]/eig_vecs[:,i].sum())
    
    

class WorkerProblem:
    '''
    Solves the worker problem for a set of parameters and government policies
    '''
    def __init__(self,beta,p,w,alpha,sigma):
        '''
        Initializes worker problem class with
        
        Parameters
        ===========
        
        beta : discount factor worker
        
        p : (ndarray) p[j] is the probability of receiving wage w[j]
        
        w : (ndarray) array of possibe wages the worker can receive
        
        alpha : (float) firing probability
        
        sigma: (float) Risk aversion of the worker
        '''
        self.beta = beta
        self.p = p
        self.w = w
        self.alpha = alpha
        self.sigma = sigma
        self.v0 = None
        
    def U(self,x):
        '''
        Returns the utility of the agent
        '''
        sigma = self.sigma
        if sigma == 1:
            return np.log(x)
        else:
            return (x**(1-sigma)-1.)/(1.-sigma)
        
    def iterateValueFunction(self,c,tau,v):
        '''
        Iterates workers bellman equation
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        v : (ndarray) current value function
        
        Returns
        ========
        
        vnew : (ndarray) new value function
        
        choice :(ndarrary) optimal decision rule of the worker
        '''
        S = len(self.p)
        beta = self.beta
        alpha = self.alpha
        Q = self.p.dot(v)# value before wage offer
        #stack value of accepting and rejecting offer on top of each other 
        stacked_values = np.vstack(( self.U(c)*np.ones(S) + beta*Q,
        self.U(self.w*(1-tau)) + (1-alpha)*beta*v + alpha*beta*Q )) 
        #find whether it is optimal to accept or reject offer
        v_new = np.amax(stacked_values, axis = 0)
        choice = np.argmax(stacked_values, axis = 0)         
        return v_new,choice
        
    def solveBellmanEquation(self,c,tau,eps = 1e-10):
        '''
        Solves workers bellman equation given government policies
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        V : (ndarray)  value function
        
        Choice :(ndarrary) optimal decision rule of the worker
        '''
        S = len(self.p)
        if self.v0 == None:
            v = np.zeros(S) #intialize with zero
        else:
            v = self.v0
        diff = 1 #holds difference v_{t+1}-v_t
        while diff > eps:
            vnew,choice = self.iterateValueFunction(c,tau,v)
            diff = np.amax(np.abs(v-vnew))
            v = vnew
            
        self.v0 = v
        return v,choice
        
    def constructTransitionMatrix(self,c,tau):
        '''
        Computes the transition matrix of the worker of the infinite horizon
        problem given government policy
         Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        P : (ndarray)  Transition matrix taking s=0 as unemployed
        '''
        p = self.p
        J = len(p)
        S = J+1
        P = np.zeros((S,S))
        _,C = self.solveBellmanEquation(c,tau)
        
        P[0,1:] = C*p
        P[0,0] = 1-C.dot(p)
        
        for j in range(1,S):
            if C[j-1] == 0:
                P[j,0] = 1. 
            else:
                P[j,0] = self.alpha
                P[j,j] = 1-self.alpha
        return P
        
    def constructSteadyState(self,c,tau):
        '''
        Finds the steady state distribution of worker productivities
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        pi : (ndarray)  steady state distribution
        '''
        return findUnitEigenvector(self.constructTransitionMatrix(c,tau).T)
        
    def computeSS_Deficit(self,c,tau):
        '''
        Computes the governments budget deficit in the steady state
        
        Parameters
        ===========
        
        c: (float) unemployment benefits
        
        tau : (float) proportional tax rate
        
        Returns
        ========
        
        deficit :   (float) government unemployment payments minus tax income
        '''
        pi = self.constructSteadyState(c,tau)
        return pi[0]*c - pi[1:].dot(self.w*tau)
        
    def computeSS_Welfare(self,c,tau):
        '''
        Computes the governemnts steady state welfare
        '''
        pi = self.constructSteadyState(c,tau)
        V,_ = self.solveBellmanEquation(c,tau)
        
        Q = self.p.dot(V)
        
        return pi[0]*Q + pi[1:].dot(V)
        
        
def bracket_and_solve(f):
    '''
    Helper function.  Given a decreasing function f on [0,1] will find the 
    root of that function.
    
    Parameters
    ===========
    
    f   :   A function f:[0,1]->R
    
    Returns
    ========
    x0 such that f(x0) = 0
    '''
    x0 = 0.2
    if f(x0) < 0.:
        x1 = x0/1.1
        while f(x1) < 0:
            x0 = x1
            x1 = x0/1.1
        return brentq(f,x1,x0)
    elif f(x0) > 0:
        x1  =  0.9*x0+0.1
        while f(x1) > 0.:
            x0 = x1
            x1 = 0.9*x0+0.1
        return brentq(f,x0,x1)
    
        

def compute_tau(WP,c):
    '''
    Computes the tax rate that balances the governments budget contraint
    Parameters
    ==========
    
    WP  :   An instance of WorkerProblem class
    
    c   :   Unemployement benefits
    
    Returns
    ========
    
    tau :   Budget constraint balancing tax rate
    '''
    return  bracket_and_solve(lambda tau : WP.computeSS_Deficit(c,tau))
