# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 11:32:39 2014

@author: dgevans
"""
from matplotlib.pylab import *
import lake_model as lm

b = 0.001808
d = 0.0008333
alpha = 0.012
lamb = 0.2486

A = lm.ConstructA_matrix(lamb,alpha,b,d)
Ahat = lm.ScaledA_matrix(lamb,alpha,b,d)

print linalg.eig(A)
print linalg.eig(Ahat)
print lm.SteadyState(lamb,alpha,b,d)

x0 = [0.92,0.08]
xHist = lm.SimulateTransitionPath(x0,A,50)

figure()
subplot(211)
plot(xHist[:,0])
subplot(212)
plot(xHist[:,1])

xHist = lm.SimulateTransitionPath(x0,Ahat,50)

figure()
subplot(211)
plot(xHist[:,0])
subplot(212)
plot(xHist[:,1])


#part g
P = lm.Construct_P_Matrix(lamb,alpha,d)
print "P^5:"
print P**5
print "P^10:"
print P**10

pi0 = array([1.,0.,0.])
print "pi_5:"
print pi0*(P**5)
print "pi_10:"
print pi0*(P**10)

#now simulate transitions
sHists = zeros((2000,1000),int)
for k in range(2000):
    sHists[k,:] = lm.simulateLife(0,P,1000)

ret = mean(sHists[:,-1]==2)
print 'fraction "retired":'
print ret

print 'fraction unemployed:'
print mean(sHists[:,-1]==0)/(1-ret)

print 'fraction employed:'
print mean(sHists[:,-1]==1)/(1-ret)


#Repeat for d = 0
P = lm.Construct_P_Matrix(lamb,alpha,0)
print "P^5:"
print P**5
print "P^10:"
print P**10

pi0 = array([1.,0.,0.])
print "pi_5:"
print pi0*(P**5)
print "pi_10:"
print pi0*(P**10)

#now simulate transitions
sHists = zeros((2000,1000),int)
for k in range(2000):
    sHists[k,:] = lm.simulateLife(0,P,1000)

ret = mean(sHists[:,-1]==2)
print 'fraction "retired":'
print ret

print 'fraction unemployed:'
print mean(sHists[:,-1]==0)/(1-ret)

print 'fraction employed:'
print mean(sHists[:,-1]==1)/(1-ret)


#Last Part
w = 10.
c = 4.
N = 100.
e,u = lm.SteadyState(lamb,alpha,0.,0.)[:2]

u_cost = N*u*c

tau = u_cost/(N*w*e)


