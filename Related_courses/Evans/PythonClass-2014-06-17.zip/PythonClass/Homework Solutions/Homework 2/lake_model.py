# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 11:16:52 2014

@author: dgevans
"""
import numpy as np

def ConstructA_matrix(lamb,alpha,b,d):
    '''
    Constructs the A matrix for $X_{t+1} = A X_{t}$ where X_t = (E_t,U_t)
    
    Parameters
    -----------
        lamb - lambda, job finding rate for surviving unemployed workers (float)
        alpha - dismissisal rate for surviving employed people (float)
        b - entry rate into labor force
        d - exit rate from the labor force
        
    Returns
    --------
        A - (2x2) matrix governing state dynamics
    '''
    return np.array([ [(1-d)*(1-alpha), (1-d)*lamb],
                      [(1-d)*alpha + b, (1-lamb)*(1-d) + b ]])
                      

def SteadyState(lamb,alpha,b,d):
    '''
    Computes steady state unemployment rate u and net job creation rate f
    
    Parameters
    -----------
        lamb - lambda, job finding rate for surviving unemployed workers (float)
        alpha - dismissisal rate for surviving employed people (float)
        b - entry rate into labor force
        d - exit rate from the labor force
        
    Returns
    --------
        e - steady state employment rate (float)
        u - steady state unemployment rate (float)
        f - job creation rate (float)
    '''
    u = ( b+alpha*(1-d) )/( b+alpha*(1-d)+lamb*(1-d)  )
    e = 1-u
    f = (b-d)*e
    return e,u,f
    
def ScaledA_matrix(lamb,alpha,b,d):
    '''
    Constructs the scaled A matrix for $x_{t+1} = Ahat x_{t}$ where 
    x_t = (E_t/N_t,U_t/N_t) = (e_t,u_t)
    
    Variables
    ----------
        lamb - lambda, job finding rate for surviving unemployed workers (float)
        alpha - dismissisal rate for surviving employed people (float)
        b - entry rate into labor force
        d - exit rate from the labor force
        
    Returns
    --------
        Ahat - (2x2) matrix governing state dynamics for employment rates.
    '''
    A = ConstructA_matrix(lamb,alpha,b,d)
    g = b-d
    return A/(1+g)
    
def SimulateTransitionPath(x0,A,T):
    '''
    Simulate the transition path from $x_0$ for $T$ periods.
    
    Variables
    ----------
        x0 - initial state (length 2 array)
        A - transition matrix 
        T - number of periods for simulation
        
    Returns
    ---------
        xHist - Path of x_t for T period (Tx2 array)
    '''

    #initialize history matrix
    x = np.zeros((T,2))
    #Fill first row of x with initial conditions
    x[0] = x0
    #simulate
    for t in range(1,T):
        x[t] = A.dot(x[t-1])
    return x
    
def Construct_P_Matrix(lamb,alpha,d):
    '''
    Constructs the stochastic transition matrix P for an individual who can be
    unemployed (state 0), employed (state 1), and deceased (state 2).  P satisfies
    
    :math:`P_{ij} = Prob(s_{t+1}=j|s_t = i)`
    
    Parameters
    -----------
    lamb    :  lambda, job finding rate for surviving unemployed workers (float)
        
    alpha   :   dismissisal rate for surviving employed people (float)
    
    d   :   exit rate from the labor force
    
    Returns
    -------
        P: (3x3) matrix governing state dynamics
    '''
    P = np.zeros((3,3))#initialize
    P[0] = [(1-d)*(1-lamb), (1-d)*lamb, d] #transition probabilities for unemployed
    P[1] = [(1-d)*alpha, (1-d)*(1-alpha), d] #transition probabilities for employed
    P[2] = [0,0,1] #Once you die you stay dead: NO ZOMBIES
    return np.matrix(P)
    
    
def simulateLife(s0,P,T):
    '''
    Simulates the lifetime experience of an agent who starts out at state s0
    and follows stochastic transition P for T periods.
    
    Parameters
    ------------
        s0 : (int) initial state of the agent
        P : (2x2) Transition matrix
        T : number of periods lived
        
    Returns
    --------
        s : (T array) The sample path :math:`\{s_t\}^T` for the agent
    '''
    P = np.array(P) #take P to be an array to make compatible with random_choice
    S = len(P)
    s = np.zeros(T,int)#allocate space for $s$ 
    s[0] = s0#intialize s[0] for s0
    for t in range(0,T-1):
        s[t+1] = random_choice(range(S),P[s[t]])
    return s
    
def random_choice(s,p):
    '''
    Chooses random element from set s based on probability weights p
    
    Parameters
    -----------
    s : list of values to choose from
    p : probability weights on these values
    
    Returns
    --------
    s_rand: random choice from s
    
    '''
    cump = np.cumsum(p)
    r = np.random.random_sample()
    for i,cp in enumerate(cump):
        if r < cp:
            break
    return s[i]
