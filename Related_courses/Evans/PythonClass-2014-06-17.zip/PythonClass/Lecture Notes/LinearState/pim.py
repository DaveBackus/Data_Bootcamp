# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 08:10:04 2014

@author: dgevans
"""
import numpy as np
import matplotlib.pyplot as plt
from lss import LSS

def pim_solution(beta, A, C, G, x_0,b_0):
    """
    Returns LSS class holding solution to the PIM where income y_t is 
    governeed by
    
        x_{t+1} = A x_t + C w_{t+1}
            y_t = G x_t 
    
    where {w_t} are iid and N(0, I). Along with x_0 and b_0
    
    """
    beta = beta
    A, G, C = map(np.atleast_2d, (A, G, C))
    n = len(A)
    C = C.reshape(n,-1)
    _,m = C.shape
    #construct new system with additional b state variable.  Add b and c 
    # to observation equation
    I = np.eye(n)
    Ahat = np.zeros((n+1,n+1))
    Ahat[:n,:n] = A
    Ahat[-1,:n] = G.dot(np.linalg.inv(I - beta*A)).dot(A-I)
    Ahat[-1,n] = 1
    
    Ghat = np.zeros((3,n+1))
    Ghat[0,:n] = G #y
    Ghat[1,n] = 1 #b
    Ghat[2,:n] = (1-beta)*G.dot(np.linalg.inv(I-beta*A))
    Ghat[2,n] = -(1-beta)
    
    Chat = np.zeros((n+1,m))
    Chat[:n,:] = C
    
    mu_0 = np.zeros(n+1)
    mu_0[:n] = x_0
    mu_0[n] = b_0
    
    return LSS(Ahat,Chat,Ghat,mu_0)
        
def ImpulseResponse(mod,w0,T):
    '''
    Simulates an impulse response where w[1] = w0 and w[t] = 0 for all
    t > 1
    '''
    w = np.zeros((mod.m,T+1))
    w[:,1] = w0
    x,y = mod.simulate(T,w)
    y,b,c = y
    return y,b,c
    
def plotImpulseResponce(mod,w0,T):
    '''
    Plots the impulse response of model
    '''
    y,b,c = ImpulseResponse(mod,w0,T)
    plt.subplot(311)
    plt.plot(y)
    plt.ylabel(r'$y_t$')
    plt.subplot(312)
    plt.plot(b[1:]) #want to plot b_{t+1}
    plt.ylabel(r'$b_{t+1}$')
    plt.subplot(313)
    plt.plot(c)
    plt.ylabel(r'$c_t$')
    plt.xlabel('t')
    
def plotPaths(mod,T,N,beta):
    '''
    Plot sequences of income debt and consumption for N agents
    '''
    _,yhat = mod.replicate(T,N)
    for j in range(N):
        rcolor = np.random.choice(('c','g','b','k'))
        y,b,c = yhat[j,:,:]
        plt.subplot(411)
        plt.plot(y,color=rcolor,lw=1,alpha=0.5)
        plt.subplot(412)
        plt.plot(b[1:],color=rcolor,lw=1,alpha=0.5)
        plt.subplot(413)
        plt.plot(c,color=rcolor,lw=1,alpha=0.5)
        plt.subplot(414)
        plt.plot(c+(1-beta)*b,color=rcolor,lw=1,alpha=0.5)
    plt.subplot(411)
    plt.ylabel(r'$y_t$')
    plt.subplot(412)
    plt.ylabel(r'$b_{t+1}$')
    plt.subplot(413)
    plt.ylabel(r'$c_{t}$')
    plt.subplot(414)
    plt.ylabel(r'$c_t+(1-\beta) b_{t}$')
    plt.xlabel(r't')
        
        