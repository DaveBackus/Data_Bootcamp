# -*- coding: utf-8 -*-
"""
Created on Tue Apr 15 08:42:22 2014

@author: dgevans
"""
from matplotlib.pylab import *
import numpy as np
from pim import pim_solution
from pim import plotImpulseResponce
from pim import plotPaths
x_0 = np.array([0,1])
beta = 1/(1.05)


#iid
A = np.zeros((2,2))
A[1,1] = 1.
G = np.array([1,1])
C = np.array([0.15,0]).reshape(-1,1)
iid = pim_solution(beta,A,C,G,x_0,0.)

#persistance
A[0,0] = 0.9
pers = pim_solution(beta,A,C,G,x_0,0.)

#persistance and transitory
A = np.zeros((3,3))
A[1,1] = 1.
A[2,2] = 1.
G = np.array([1,1,1])
C = np.zeros((3,2))
C[0,0],C[1,1] = 0.15,0.15
x_0 = np.array([0.,0.,1.])
pers_trans = pim_solution(beta,A,C,G,x_0,0.) 



#examples
plotPaths(iid,100,50,beta)

figure()
plotImpulseResponce(iid,1,30)

figure()
plotImpulseResponce(pers,1,30)

figure()
plotImpulseResponce(pers_trans,[1,0],30)
plotImpulseResponce(pers_trans,[0,1],30)
legend(('transitory','persistant'),loc='best')


