import numpy as np
from numpy import dot
from numpy.random import multivariate_normal
from scipy.linalg import solve

class LSS:

    def __init__(self, A, C, G, mu_0=None, Sigma_0=None):
        """
        Provides initial parameters describing the state space model

            x_{t+1} = A x_t + C w_{t+1}
                y_t = G x_t 

        where {w_t} are iid and N(0, I).  If the initial conditions mu_0 and
        Sigma_0 for x_0 ~ N(mu_0, Sigma_0) are not supplied, both are set to
        zero. When Sigma_0=0, the draw of x_0 is exactly mu_0.
        
        Parameters
        ============
        
        All arguments should be scalars or array_like

            * A is n x n
            * C is n x m
            * G is k x n
            * mu_0 is n x 1
            * Sigma_0 is n x n, positive definite and symmetric

        """
        self.A, self.G, self.C = map(np.atleast_2d, (A, G, C))
        self.k, self.n = self.G.shape
        self.m = self.C.shape[1]
        # == Default initial conditions == #
        if mu_0 == None:
            self.mu_0 = np.zeros((self.n, 1))
        else:
            self.mu_0 = np.asarray(mu_0)
        if Sigma_0 == None:
            self.Sigma_0 = np.zeros((self.n, self.n))
        else:
            self.Sigma_0 = Sigma_0

    def simulate(self, ts_length=100):
        """
        Simulate a time series of length ts_length, first drawing 
        
            x_0 ~ N(mu_0, Sigma_0)


        Returns
        ========
        x : numpy.ndarray
            An n x ts_length array, where the t-th column is x_t

        y : numpy.ndarray
            A k x ts_length array, where the t-th column is y_t

        """
        x = np.empty((self.n, ts_length))
        x[:,0] = multivariate_normal(self.mu_0, self.Sigma_0)
        w = np.random.randn(self.m, ts_length-1)
        for t in range(ts_length-1):
            x[:, t+1] = self.A.dot(x[:, t]) + self.C.dot(w[:, t])
        y = self.G.dot(x)
        return x, y

    def replicate(self, T=10, num_reps=100):
        """
        Simulate num_reps observations of x and y for T periods given 
        x_0 ~ N(mu_0, Sigma_0).

        Returns
        ========
        x : numpy.ndarray
            An num_reps arrayx n x T 

        y : numpy.ndarray
            A num_reps array x k x T, 
        """
        #preallocate space
        x = np.empty((num_reps,self.n,T))
        y = np.empty((num_reps,self.k,T))
        for j in range(num_reps):
            x[j,:,:],y[j,:,:] = self.simulate(ts_length=T)
        return x, y
        
    def ensemble(self, T=10, num_reps=100):
        """
        Simulate num_reps observations of x_T and y_T given 
        x_0 ~ N(mu_0, Sigma_0).

        Returns
        ========
        x : numpy.ndarray
            An n x num_reps array, where the j-th column is the j_th
            observation of x_T

        y : numpy.ndarray
            A k x num_reps array, where the j-th column is the j_th
            observation of y_T
        """
        x = np.empty((self.n, num_reps))
        for j in range(num_reps):
            x_T, _ = self.simulate(ts_length=T+1)
            x[:, j] = x_T[:, -1]
        y = self.G.dot(x)
        return x, y
        
    

    def iterate_moments(self,mu_x ,Sigma_x ):
        """
        Given distribution of $x$ for the current period constructs distribution of $x$ next period and $y for the current period  
        
        Parameters
        ===========
        
        mu_x : numpy.ndarray
            An n x 1 array representing the polution mean of x_{t}
            
        Sigma_x : numpy.ndarray
            An n x n array representing the variance-covariance matrix of x_{t}

        Returns
        ========

        A tuple containing the moments of the current distribution.  The moments are returned as a 4-tuple with
        the following interpretation:

        mu_x_prime : numpy.ndarray
            An n x 1 array representing the population mean of x_{t+1}
            
        Sigma_x_prime : numpy.ndarray
            An n x n array representing the variance-covariance matrix of x_{t+1}

        mu_y : numpy.ndarray
            A  k x 1 array representing the population mean of y_t

        Sigma_y : numpy.ndarray
            A k x k array representing the variance-covariance matrix of y_t

        """
        # == Simplify names == #
        A, C, G = self.A, self.C, self.G
        # == Update moments of x == #
        mu_x_prime = A.dot(mu_x)
        Sigma_x_prime = A.dot(Sigma_x).dot(A.T) + C.dot(C.T)
        # == Compute moments of y == #
        mu_y, Sigma_y = G.dot(mu_x), G.dot(Sigma_x).dot(G.T)
        return mu_x_prime, Sigma_x_prime, mu_y, Sigma_y

    def unconditional_moments(self,T):
        """
        Constructs series of unconditional moments of $x$ and $y$ for 
        $T$ periods
        
        Parameters
        ===========
        
        T : Number of periods to construct moments for

        Returns
        ========

        A tuple containing the moments of the current distribution.  The moments are returned as a 4-tuple with
        the following interpretation:

        mu_x_prime : numpy.ndarray
            An T+1x n array representing the population mean of x_t
            
        Sigma_x_prime : numpy.ndarray
            An T+1 x n x n array representing the variance-covariance matrix of x_t

        mu_y : numpy.ndarray
            A  T+1 x k array representing the population mean of y_t

        Sigma_y : numpy.ndarray
            A T+1 x k x k array representing the variance-covariance matrix of y_t

        """
        mu_x,Sigma_x = np.zeros((T+2,self.n)),np.zeros((T+2,self.n,self.n))
        mu_y,Sigma_y = np.zeros((T+1,self.k)),np.zeros((T+1,self.k,self.k))
        mu_x[0],Sigma_x[0] = self.mu_0,self.Sigma_0
        for t in range(T+1):
            mu_x[t+1],Sigma_x[t+1],mu_y[t],Sigma_y[t] = self.iterate_moments(mu_x[t],Sigma_x[t])
            
        return mu_x[:-1],Sigma_x[:-1],mu_y,Sigma_y
        
    def stationary_distributions(self, max_iter=200, tol=1e-5):
        """
        Compute the moments of the stationary distributions of x_t and y_t if
        possible.  Computation is by iteration, starting from the initial
        conditions self.mu_0 and self.Sigma_0

        Returns
        ========
        mu_x_star : numpy.ndarray
            An n x 1 array representing the stationary mean of x_t

        mu_y_star : numpy.ndarray
            An k x 1 array representing the stationary mean of y_t

        Sigma_x_star : numpy.ndarray
            An n x n array representing the stationary var-cov matrix of x_t

        Sigma_y_star : numpy.ndarray
            An k x k array representing the stationary var-cov matrix of y_t

        """
        # == Initialize iteration == #
        G = self.G
        mu_x, Sigma_x, mu_y, Sigma_y = self.mu_0, self.Sigma_0, G.dot(self.mu_0), G.dot(self.Sigma_0).dot(G.T)
        i = 0
        error = tol + 1
        # == Loop until convergence or failuer == #
        while error > tol:

            if i > max_iter:
                fail_message = 'Convergence failed after {} iterations'
                raise ValueError(fail_message.format(max_iter))

            else:
                i += 1
                mu_x1, mu_y1, Sigma_x1, Sigma_y1 = self.iterate_moments(mu_x,Sigma_x)
                error_mu = np.max(np.abs(mu_x1 - mu_x))
                error_Sigma = np.max(np.abs(Sigma_x1 - Sigma_x))
                error = max(error_mu, error_Sigma)
                mu_x, Sigma_x = mu_x1, Sigma_x1

        # == Prepare return values == #
        mu_x_star, Sigma_x_star = mu_x, Sigma_x
        mu_y_star, Sigma_y_star = mu_y1, Sigma_y1
        return mu_x_star, mu_y_star, Sigma_x_star, Sigma_y_star


    def geometric_sums(self, beta, x_t):
        """
        Forecast the geometric sums

            S_x := E_t [sum_{j=0}^{\infty} beta^j x_{t+j} | x_t ]

            S_y := E_t [sum_{j=0}^{\infty} beta^j y_{t+j} | x_t ]

        Parameters
        ===========
        beta : float
            Discount factor, in [0, 1)

        beta : array_like
            The term x_t for conditioning

        Returns
        ========
        S_x : numpy.ndarray
            Geometric sum as defined above

        S_y : numpy.ndarray
            Geometric sum as defined above

        """
        I = np.identity(self.n)
        S_x = solve(I - beta * self.A, x_t)
        S_y = self.G.dot(S_x)
        return S_x, S_y