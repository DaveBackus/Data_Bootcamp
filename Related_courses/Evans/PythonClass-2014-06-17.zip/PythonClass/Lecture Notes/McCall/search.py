# -*- coding: utf-8 -*-
"""
Created on Mon Mar 24 11:43:00 2014

@author: dgevans
"""
import numpy as np


def iterateValueFunction_nofire(beta, p, w, c, v):
    '''
    Iterates McCall search value function v
    
    Parameters
    ----------
    beta - (float) discount factor
    p  - (n array) p[s] is the probability of state s
    w - (n array) w[s] is the wage in state s
    c - (float) unemployment benefit
    v - (n array) continuation value function if offered w[s] next period
    
    Returns
    --------
    v_new - (n array) current value function if offered w[s] this period
    choice - (n array) do we accept or reject wage w[s]
    '''
    S = len(p)
    #stack the two value of two choices together
    stacked_values = np.vstack( (c*np.ones(S)  + beta*p.dot(v), 
                                 w + beta*v) )
    #use amax to choose maximal value
    v_new = np.amax(stacked_values, axis = 0)
    choice = np.argmax(stacked_values, axis = 0)
    return v_new,choice
    

def iterateValueFunction(beta,p,w,c,alpha,v,u):
    '''
    Iterates McCall search value function v and unemployment value u with firing
    
    Parameters
    ----------
    beta - (float) discount factor
    p  - (n array) p[s] is the probability of state s
    w - (n array) w[s] is the wage in state s
    c - (float) unemployment benefit
    alpha - (float) probability of being fired
    v - (n array) continuation value function if offered w[s] next period
    u - (float) value of being unemployed (no offer) next period
    
    Returns
    --------
    v_new - (n array) current value function if offered w[s] this period
    u_new - (float) current value of being unemployed
    choice - (n array) do we accept or reject wage w[s]
    '''
    S = len(p)
    Q = p.dot(v)# value before wage offer
    #stack value of accepting and rejecting offer on top of each other
    stacked_values = np.vstack((c*np.ones(S)  + beta*Q, 
                                w + (1-alpha)*beta*v + alpha*beta*u  ))
    #find whether it is optimal to accept or reject offer
    v_new = np.amax(stacked_values, axis = 0)
    choice = np.argmax(stacked_values, axis = 0)
    u_new= c+ beta*Q
    return v_new,u_new,choice
    
def solveMcCallModel(beta,p,w,c,alpha,Ts=[],eps = 1e-10):
    '''
    Solves McCall search model for various horizons Ts
    
    Parameters
    ----------
    beta - (float) discount factor
    p  - (n array) p[s] is the probability of state s
    w - (n array) w[s] is the wage in state s
    c - (float) unemployment benefit
    alpha - (float) probability of being fired
    Ts - (list) finte horizons at which to solve the problem
    eps - (float) convergence criterion for infinite horizon 
    
    Returns
    --------
    V - (dict) Vs[T][s] current value function if offered w[s] with T periods left
    U - (dict) Us[T] current value of being unemployed with T periods left
    Choice - (dict) choies[T][s] do we accept or reject wage w[s]  with T periods left
    '''
    S = len(p)
    v = np.zeros(S) #intialize with zero
    u = 0
    t = 1
    diff = 1 #holds difference v_{t+1}-v_t
    V,U,Choice = {},{},{} #initialize return variables
    while diff > eps:
        v_new,u_new,choice = iterateValueFunction(beta,p,w,c,alpha,v,u)
        if t in Ts:
            V[t] = v_new
            U[t] = u_new
            Choice[t] = choice
        t += 1
        diff = np.amax( np.abs(v-v_new) )#compute difference between values
        v = v_new #copy v_new into v
        u = u_new
    #add in infinte horizon solution
    V[np.inf] = v
    Choice[np.inf] = choice
    U[np.inf] = u
    return V,U,Choice
    
def solveMcCallFiniteUnemployment(beta,p,w,c,TU,eps = 1e-10):
    '''
    Solves McCall search model assumming you can only receive unemployment 
    benefits for TU periods
    
    Parameters
    ----------
    beta - (float) discount factor
    p  - (n array) p[s] is the probability of state s
    w - (n array) w[s] is the wage in state s
    c - (float) unemployment benefit
    TU - (int) number of perods worker can receive unemploymet benefits
    eps - (float) convergence criterion for infinite horizon 
    
    Returns
    --------
    V - (list) Vs[T][s] current value function if offered w[s] with T periods
    of unemployment benefits left
    Choice - (list) choies[T][s] do we accept or reject wage w[s]  with T periods
    of unemployment benefits left
    '''
    S = len(p)
    V = {}
    V[0] = np.zeros(S)
    diff = 1
    #Solve infinite horizon problem with no unemployment benefits
    while diff > eps:
        v_new,choice = iterateValueFunction_nofire(beta,p,w,0,V[0])
        diff = np.amax( np.abs(V[0]-v_new) )
        V[0] = v_new
    Choice = {}
    Choice[0] = choice
    
    for j in range(1,TU+1):
        V[j],Choice[j] = iterateValueFunction_nofire(beta,p,w,c,V[j-1])
        
    return V,Choice
        
        