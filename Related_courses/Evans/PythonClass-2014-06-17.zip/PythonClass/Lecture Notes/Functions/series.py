# -*- coding: utf-8 -*-
"""
Created on Thu Feb 13 18:03:37 2014

@author: dgevans
"""
from random import normalvariate
import numpy as np

def GenerateAR1Series(x0,T,rho = 0.8):
    '''
    This function produces a simulation of the process :math:`x_{t+1} = \rho*x_t +\epsilon_{t+1}`
    where :math:`\epsilon_{t+1}` is a standard normal
    Inputs:
        x0 - initial value for x (float)
        T - number of period to simulate (int)
        alpha - persistance parameter (float)
    Returns:
        x - sequence of values for x (T array)
    '''
    x = np.zeros(T) #allocate space
    x[0] = x0
    for t in range(0,T-1):
        x[t+1] = rho * x[t] + normalvariate(0,1)
    return x